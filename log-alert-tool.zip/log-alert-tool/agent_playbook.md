# Agent Playbook for Log Alert Tool

1. **Test script:** Run the log parsing script against files in the `examples/` directory and verify that it generates the expected CSV. Update the code if parsing rules change.
2. **Consistency:** Ensure the screenshot filename (`log-tool-output.png`) matches what is referenced in the README.
3. **Documentation:** Keep the README steps clear and free of stray lines. Update usage examples when CLI arguments change.
4. **Examples:** Periodically refresh the sample log and CSV in `/examples/` to cover new log formats or edge cases.
5. **Issues:** Log issues for additional features such as alert thresholds, email notifications or support for JSON logs.
