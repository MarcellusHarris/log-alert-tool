## Log Alert Tool

This simple utility scans plain‑text log files for key‑value pairs (for example, `user=` and `ip=`) and outputs a CSV summarising the structured information. Use it to quickly extract users, IP addresses and timestamps from large application or server logs.

### How to use

1. Place your log file in the working directory.  
2. Run the script (modify the command name to match your project):
   ```bash
   python log_alert.py --input sample.log --output output.csv
   ```
3. Open the generated `output.csv` to review structured records.

A small `sample.log` and corresponding `expected.csv` are included in the `examples/` folder for testing. The screenshot below shows a sample of the tool’s output when opened in a spreadsheet application.

![Log Tool Output](assets/log-tool-output.png)
