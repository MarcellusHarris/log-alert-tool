### Log Alert Tool TODOs

Final tasks for polishing this repo:

- [ ] **Unify screenshot filenames:** Use `log-tool-output.png` consistently in the README and repository.
- [ ] **README cleanup:** Remove stray CSV lines in the usage section and improve step‑by‑step instructions.
- [ ] **Examples:** Add a small log file and its corresponding CSV output under `/examples/` for testing.
- [ ] **GitHub Pages:** Ensure that any referenced GitHub Pages link still works or remove it if unnecessary.
